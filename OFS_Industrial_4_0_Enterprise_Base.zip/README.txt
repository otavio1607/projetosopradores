
OFS INDUSTRIAL 4.0 - ENTERPRISE BASE

1) Instale dependências:
cd backend
npm install

2) Configure .env baseado no .env.example

3) Execute banco:
psql -U postgres -f database.sql

4) Rode o servidor:
npm start

API disponível:
http://localhost:3000
