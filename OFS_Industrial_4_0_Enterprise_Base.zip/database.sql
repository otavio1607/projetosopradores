
CREATE DATABASE ofsindustrial;

\c ofsindustrial;

CREATE TABLE planos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(50),
    limite_equipamentos INTEGER,
    limite_usuarios INTEGER,
    valor NUMERIC(10,2)
);

CREATE TABLE empresas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150),
    cnpj VARCHAR(20),
    plano_id INTEGER REFERENCES planos(id),
    status VARCHAR(20) DEFAULT 'trial',
    data_expiracao TIMESTAMP,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    empresa_id INTEGER REFERENCES empresas(id),
    nome VARCHAR(100),
    email VARCHAR(150) UNIQUE,
    senha VARCHAR(255),
    perfil VARCHAR(20),
    ativo BOOLEAN DEFAULT true
);

CREATE TABLE equipamentos (
    id SERIAL PRIMARY KEY,
    empresa_id INTEGER REFERENCES empresas(id),
    nome VARCHAR(100),
    area VARCHAR(100),
    criticidade INTEGER
);

CREATE TABLE ordens_servico (
    id SERIAL PRIMARY KEY,
    empresa_id INTEGER REFERENCES empresas(id),
    equipamento_id INTEGER REFERENCES equipamentos(id),
    descricao TEXT,
    status VARCHAR(20),
    data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_fechamento TIMESTAMP
);
